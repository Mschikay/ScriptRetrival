package pre_process;
import java.util.StringTokenizer;

/**
 * This is for INFSCI 2140 in 2019
 * 
 * TextTokenizer can split a sequence of text into individual word tokens.
 */
public class WordTokenizer {
	// Essential private methods or variables can be added.
	StringTokenizer stringTokenizer;
	// YOU MUST IMPLEMENT THIS METHOD.
	public WordTokenizer(String texts) {
		// Tokenize the input texts.
		String delim_escap = "\n\t\r";
        String delia_punc = " &.,;:?!-+*/=_()|\\\"";
        stringTokenizer = new StringTokenizer(texts, delim_escap + delia_punc);
	}

	// YOU MUST IMPLEMENT THIS METHOD.
	public String nextWord() {
		// Return the next word in the document.
		// Return null, if it is the end of the document.
		if (stringTokenizer.hasMoreTokens()) {
		    String retTexts = stringTokenizer.nextToken();
		    return retTexts;
        }
		return null;
	}

}
