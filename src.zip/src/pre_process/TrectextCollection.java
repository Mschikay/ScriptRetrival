package pre_process;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import classes.Path;


public class TrectextCollection implements DocumentCollection {
	// Essential private methods or variables can be added.
	private FileReader fr;

    private BufferedReader br;

    private Iterator<Map.Entry<String, Object>> itr;
    
    private Map<String, String> mytitles = new HashMap<>();

    
	// YOU SHOULD IMPLEMENT THIS METHOD.
	public TrectextCollection() throws IOException {
		// 1. Open the file in Path.DataTextDir.
		// 2. Make preparation for function nextDocument().
		// NT: you cannot load the whole corpus into memory!!
		try {
            fr = new FileReader(Path.RawDataDir);
            br = new BufferedReader(fr);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	public Map<String, String> getTitles(){
		return mytitles;
	}
	
	public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            int n = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
	
	// YOU SHOULD IMPLEMENT THIS METHOD.
	public Map<String, Object> nextDocument() throws IOException {
		// 1. When called, this API processes one document from corpus, and returns its
		// doc number and content.
		// 2. When no document left, return null, and close the file.
		Map<String, Object> mydocs = new HashMap<>();
		String curr;
		String key;
		String title;
		StringBuilder content = new StringBuilder();
		int id = 0;
		int num = 0;
		
        /*
            Idea: Since we just need to care the content between <DOCNO> and </DOCNO>,
                    the content between <TEXT> and </TEXT>, so just store those information in variable content
                  And, notice that a docment begin with a <DOC>, end with a </DOC>
         */
        if ((curr = br.readLine()) != null) {
            try {
            	title = "";
            	key = "";
            	while (!isNumeric(curr)) {
            		curr = br.readLine();
            	}
            	key = curr;
            	curr = br.readLine();
            	while (curr != null && title == "") {
            		curr.trim();
            		if (curr == null || curr == "\n") {
            			curr = br.readLine();
            			continue;
            		}
            		for (int i = 0; i < curr.length(); i++) {
            			if (curr.substring(i,i + 1).equals(" ")) {
            				continue;
            			}
                		if (curr.substring(i, i + 1).equals("<")) {
                			num++;
                		}
                		else if (curr.substring(i, i + 1).equals(">")) {
                			num --;
                		}
                		else {
                			if (num == 0) {
                				title = curr.substring(i).trim();
                				title = title.replaceAll("<(.*)>", "");
                				break;
                			}
                		}
                	}
            		
            		curr = br.readLine();
            	}
            	
                while (curr != null && !curr.contains("<table width=\"85%")) {
                	if (curr.contains("<") && curr.contains(">")) {
                		curr = curr.replaceAll("<(.*)>", " ");
                		curr = curr.trim();
                    }                	
                    content.append(curr + " ");
                    curr = br.readLine();
                }                
            	System.out.println(key +" "+ title+ "\n");
                mydocs.put(key, content.toString());
                mytitles.put(key, title);
                
            } catch (IOException e) {
                e.printStackTrace();
            }
            return mydocs;
        }
        fr.close();
		br.close();
		return null;
	}

}
