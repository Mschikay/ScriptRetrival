package pre_process;
import classes.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;


public class StopWordRemover {
	// Essential private methods or variables can be added.
	private Set<String> stopWordDic;
	private FileReader fr;
	private BufferedReader br;
	// YOU SHOULD IMPLEMENT THIS METHOD.
	public StopWordRemover() {
		// Load and store the stop words from the fileinputstream with appropriate data
		// structure.
		// NT: address of stopword.txt is Path.StopwordDir
		stopWordDic = new HashSet<>();
        try {
            fr = new FileReader(Path.StopwordDir);
            br = new BufferedReader(fr);
            String curr;
            while ((curr = br.readLine()) != null) {
                stopWordDic.add(curr);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	// YOU SHOULD IMPLEMENT THIS METHOD.
	public boolean isStopword(String word) {
		// Return true if the input word is a stopword, or false if not.
		return stopWordDic.contains(word);
	}
}
