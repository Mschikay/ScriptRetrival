package pre_process;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import classes.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This is for INFSCI 2140 in 2019
 *
 */
public class TrecwebCollection implements DocumentCollection {
	// Essential private methods or variables can be added.
	private FileReader fr;

	private BufferedReader br;
	
	// YOU SHOULD IMPLEMENT THIS METHOD.
	public TrecwebCollection() throws IOException {
		// 1. Open the file in Path.DataWebDir.
		// 2. Make preparation for function nextDocument().
		// NT: you cannot load the whole corpus into memory!!
		try {
			fr = new FileReader(Path.DataWebDir);
			br = new BufferedReader(fr);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// YOU SHOULD IMPLEMENT THIS METHOD.
	public Map<String, Object> nextDocument() throws IOException {
		// 1. When called, this API processes one document from corpus, and returns its
		// doc number and content.
		// 2. When no document left, return null, and close the file.
		// 3. the HTML tags should be removed in document content.
		Map<String, Object> mydocs = new HashMap<>();
		String curr;
		String key;
		String content = "";
		
		if ((curr = br.readLine()) != null) {
            try {
                while (!curr.equals("<DOC>")) {
                	curr = br.readLine();
                }

                while (!curr.contains("<DOCNO>")) {
                	curr = br.readLine();
                }
                int end = curr.indexOf("</DOCNO>");
                key = curr.substring(7, end);
                curr = br.readLine();

                while (curr != null && !curr.contains("</DOCHDR>")) {
                	curr = br.readLine();
                }
                curr = br.readLine();
                while (curr != null && !curr.contains("</DOC>")) {
                	if (curr.contains("<") || curr.contains(">")) {
                		curr = curr.replaceAll("<.*?>", " ");
                    }
                    content += curr + " ";
                    curr = br.readLine();
                }

                mydocs.put(key, content);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return mydocs;
        }
        br.close();
        fr.close();
		return null;
	}
}
