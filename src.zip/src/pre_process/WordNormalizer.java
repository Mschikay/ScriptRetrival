package pre_process;
import classes.*;

/**
 * This is for INFSCI 2140 in 2019
 * 
 */
public class WordNormalizer {
	// Essential private methods or variables can be added.

	// YOU MUST IMPLEMENT THIS METHOD.
	public String lowercase(String word) {
		// Transform the word uppercase characters into lowercase.
		char[] chars = word.toCharArray();
		StringBuffer s = new StringBuffer();
		for (int i = 0; i < chars.length; ++i) {
			if (Character.isUpperCase(chars[i])) {
				chars[i] = Character.toLowerCase(chars[i]);
			}
			s.append(chars[i]);
			
		}
		String ret = s.toString();
//		System.out.println(ret);
		return ret;
	}

	// YOU MUST IMPLEMENT THIS METHOD.
	public String stem(String word) {
		// Return the stemmed word with Stemmer in Classes package.
		Stemmer stemmer = new Stemmer();
		char [] chars = word.toCharArray();
		stemmer.add(chars, chars.length);
		stemmer.stem();
		String s = stemmer.toString();
		return s;
	}

}
