Please simply run the HW1Main.java

totaly document count:  503473
text corpus running time: 3.76435 min

totaly document count:  198361
web corpus running time: 2.0898833333333333 min